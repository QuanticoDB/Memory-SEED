# Memory SEED - BIP39

A Tool for Converting Your MEMORY into BIP39 Standard ( 12+1 or 24+1 ) Mnemonic Phrases.

#   

# THIS TOOL MUST BE USED OFFLINE !!!
## THIS TOOL MUST BE USED OFFLINE !!!
### THIS TOOL MUST BE USED OFFLINE !!!


